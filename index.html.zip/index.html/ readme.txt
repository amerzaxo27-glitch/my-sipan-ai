​🍎 Apple Forest - Game Documentation
​1. About the Game:
Apple Forest is an interactive educational math game designed for kids. It combines learning with fun through a leveling system and a visual shop.
​2. Key Features:
​100 Progressive Levels: From basic addition to more advanced math.
​Shop System: Unlock 5 different skins using collected coins.
​Local Progress: The game saves your level and coins automatically.
​Responsive Design: Works perfectly on mobile, tablet, and desktop.
​3. Folder Contents:
​index.html: The main game file (HTML5/JavaScript).
​classMain/Main.java: A bonus Java console version of the math logic.
​readme.txt: Documentation and setup guide.
​4. How to Use:
​Open the index.html file in any web browser (Chrome, Firefox, Safari).
​No server is required, it runs locally!
​To play the Java version, go to the classMain folder and run Main.java.
​5. Technologies Used:
​HTML5 & CSS3
​Vanilla JavaScript
​Google Fonts (Poppins)
​Canvas Confetti API
